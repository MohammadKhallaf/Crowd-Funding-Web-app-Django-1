$(document).ready(function(){
    $(".menu ul").on("click",function(){
        $("li").slideToggle()
    })
    
})